/**
 * 白狐影视 - API 资源池
 * 内置 22 条影视聚合 API + 自动测速/验活
 */

/* ── 内置 API 库 ──────────────────────────────────── */
const BUILTIN_APIS = [
  { name:'闪电资源',  url:'https://sdzyapi.com/api.php/provide/vod/?ac=detail&wd=',           note:'综合丰富' },
  { name:'新浪资源',  url:'https://api.xinlangapi.com/xinlangapi.php/provide/vod/?ac=detail&wd=', note:'更新快' },
  { name:'麻豆资源',  url:'https://caiji.moduapi.cc/api.php/provide/vod/?ac=detail&wd=',      note:'稳定' },
  { name:'飞凡资源',  url:'https://api.ffzy5.tv/api.php/provide/vod/?ac=detail&wd=',          note:'高清多' },
  { name:'卧龙资源',  url:'https://collect.wolongzyw.com/api.php/provide/vod/?ac=detail&wd=', note:'电影全' },
  { name:'暗夜资源',  url:'https://api.apibdzy.com/api.php/provide/vod/?ac=detail&wd=',       note:'备用' },
  { name:'黑木耳',    url:'https://heimuer.xyz/api.php/provide/vod/?ac=detail&wd=',           note:'动漫好' },
  { name:'OK资源',    url:'https://okzy.tv/api.php/provide/vod/?ac=detail&wd=',               note:'' },
  { name:'1080资源',  url:'https://api.1080b.com/api.php/provide/vod/?ac=detail&wd=',         note:'超清优先' },
  { name:'CK180',     url:'https://ck180.top/api.php/provide/vod/?ac=detail&wd=',             note:'' },
  { name:'真不卡',    url:'https://zhenbukaapi.com/api.php/provide/vod/?ac=detail&wd=',       note:'综艺全' },
  { name:'量子资源',  url:'https://lziapi.com/api.php/provide/vod/?ac=detail&wd=',            note:'' },
  { name:'索尼资源',  url:'https://api.sonimov.com/api.php/provide/vod/?ac=detail&wd=',       note:'日韩多' },
  { name:'天天资源',  url:'https://ttzy.tv/api.php/provide/vod/?ac=detail&wd=',               note:'' },
  { name:'图腾资源',  url:'https://api.ttnb.me/api.php/provide/vod/?ac=detail&wd=',           note:'' },
  { name:'BFZY资源',  url:'https://bfzy.tv/api.php/provide/vod/?ac=detail&wd=',               note:'' },
  { name:'金鹰资源',  url:'https://jy.cjhwapi.com/api.php/provide/vod/?ac=detail&wd=',       note:'国产剧全' },
  { name:'科技资源',  url:'https://kjzy.tv/api.php/provide/vod/?ac=detail&wd=',               note:'' },
  { name:'我的资源',  url:'https://www.wodzyapi.com/api.php/provide/vod/?ac=detail&wd=',      note:'' },
  { name:'天狼资源',  url:'https://api.tlzyw.com/api.php/provide/vod/?ac=detail&wd=',         note:'' },
  { name:'豆瓣资源',  url:'https://apizy.cc/api.php/provide/vod/?ac=detail&wd=',              note:'' },
  { name:'万达资源',  url:'https://api.wdzy.me/api.php/provide/vod/?ac=detail&wd=',           note:'更新及时' },
];

const APIS_KEY = 'baihu_apis_v3';

/* ── 加载/保存 ────────────────────────────────────── */
function loadApiList() {
  try {
    const raw = localStorage.getItem(APIS_KEY);
    if (raw) {
      const list = JSON.parse(raw);
      if (Array.isArray(list) && list.length > 0) return list;
    }
  } catch {}
  // 首次：返回内置列表，未测试状态
  return BUILTIN_APIS.map((a, i) => ({
    ...a,
    id: 'b' + i,
    status: 'unknown',
    latency: null,
    enabled: true,
    custom: false,
  }));
}

function saveApiList(list) {
  try { localStorage.setItem(APIS_KEY, JSON.stringify(list)); } catch {}
}

/* ── 测试单个 API ─────────────────────────────────── */
async function testApiItem(api, kw = '电影', ms = 7000) {
  const raw = api.url + encodeURIComponent(kw);
  const via = `/api/proxy?url=${encodeURIComponent(raw)}`;
  const t0 = Date.now();

  for (const ep of [raw, via]) {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), ms);
    try {
      const r = await fetch(ep, { signal: ctrl.signal });
      clearTimeout(tid);
      if (!r.ok) continue;
      const j = await r.json().catch(() => null);
      if (j && j.list !== undefined) {
        return { ok: true, latency: Date.now() - t0, count: j.list?.length ?? 0 };
      }
    } catch (e) {
      clearTimeout(tid);
      if (e.name === 'AbortError') return { ok: false, latency: null, error: '超时' };
    }
  }
  return { ok: false, latency: null, error: '无响应' };
}

/* ── 并发批量测试 ─────────────────────────────────── */
async function batchTestApis(apis, onProgress, concurrency = 4) {
  const results = new Array(apis.length).fill(null);
  let cursor = 0;

  async function worker() {
    while (cursor < apis.length) {
      const idx = cursor++;
      try {
        results[idx] = await testApiItem(apis[idx]);
      } catch {
        results[idx] = { ok: false, error: '异常' };
      }
      onProgress?.(results.filter(Boolean).length, apis.length, apis[idx]?.name, results[idx]);
    }
  }

  await Promise.all(Array.from({ length: Math.min(concurrency, apis.length) }, worker));
  return results;
}

window.BUILTIN_APIS    = BUILTIN_APIS;
window.loadApiList     = loadApiList;
window.saveApiList     = saveApiList;
window.testApiItem     = testApiItem;
window.batchTestApis   = batchTestApis;
