/**
 * 白狐影视 v3.0
 * 功能：密码登录 / 首页轮播 / 播放器 / API管理 / D1云同步
 */
'use strict';

/* ══════════════════════════════════════════════════════
   全局状态
══════════════════════════════════════════════════════ */
const G = {
  apis:    loadApiList(),
  cfg:     loadCfg(),
  hist:    loadHist(),
  hero:    { items:[], cur:0, timer:null },
  list:    { all:[], filtered:[], page:1, kw:'' },
  play:    { item:null, ep:0, src:0 },
  editId:  null,   // null=新增, string=编辑
  token:   sessionStorage.getItem('bh_token') || '',
};

/* ══════════════════════════════════════════════════════
   存储
══════════════════════════════════════════════════════ */
function loadCfg() {
  try {
    return {
      res:'360', autoPlay:true, progress:true, autoSrc:true, theme:'dark',
      ...JSON.parse(localStorage.getItem('baihu_cfg') || '{}'),
    };
  } catch { return { res:'360', autoPlay:true, progress:true, autoSrc:true, theme:'dark' }; }
}
function saveCfg()  { localStorage.setItem('baihu_cfg',  JSON.stringify(G.cfg)); }
function loadHist() { try { return JSON.parse(localStorage.getItem('baihu_hist') || '[]'); } catch { return []; } }
function saveHist() { localStorage.setItem('baihu_hist', JSON.stringify(G.hist)); }

/* ══════════════════════════════════════════════════════
   工具
══════════════════════════════════════════════════════ */
const $  = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);

function toast(msg, dur = 2400) {
  const el = $('toast');
  el.textContent = msg;
  el.className = 'toast show';
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.className = 'toast'; }, dur);
}

function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c =>
    ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[c])
  );
}

function uid() { return 'u' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }

/* ══════════════════════════════════════════════════════
   登录
══════════════════════════════════════════════════════ */
function togglePwd() {
  const inp = $('pwdInput');
  inp.type = inp.type === 'password' ? 'text' : 'password';
}

async function doLogin() {
  const pwd = $('pwdInput').value.trim();
  if (!pwd) { shakeLogin('请输入密码'); return; }

  try {
    const r = await fetch('/api/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: pwd }),
    });
    const j = await r.json().catch(() => ({}));
    if (j.ok) {
      G.token = j.token;
      sessionStorage.setItem('bh_token', G.token);
      enterApp();
    } else {
      shakeLogin('密码错误，请重试');
    }
  } catch {
    // 网络故障时用 sessionStorage 存的 token 对比（离线模式）
    shakeLogin('网络异常，请稍后再试');
  }
}

function shakeLogin(msg) {
  $('loginErr').textContent = msg;
  $('loginBox').classList.remove('login-shake');
  void $('loginBox').offsetWidth;  // reflow
  $('loginBox').classList.add('login-shake');
}

$('pwdInput').addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

function enterApp() {
  $('loginPage').style.display = 'none';
  $('app').style.display = 'block';
  applyTheme(G.cfg.theme);
  loadHlsJs();
  buildHome();
  loadHero();
}

// 如果已有 token（刷新页面），自动进入
if (G.token) {
  // 简单验证 token 格式后直接进入，避免每次刷新都要输密码
  fetch('/api/auth', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password: G.token }),
  }).then(r => r.json()).then(j => {
    if (j.ok) enterApp();
    else { G.token = ''; sessionStorage.removeItem('bh_token'); }
  }).catch(() => {
    // 网络异常：若 token 非空则直接进入（允许离线使用）
    if (G.token) enterApp();
  });
}

/* ══════════════════════════════════════════════════════
   API 请求层（自动轮换，含 CF Pages 代理）
══════════════════════════════════════════════════════ */
function enabledApis() { return G.apis.filter(a => a.enabled !== false); }

async function fetchByKw(kw, startIdx = 0) {
  const apis = enabledApis();
  if (!apis.length) { toast('请先在设置中配置API'); return null; }

  for (let i = startIdx; i < apis.length; i++) {
    const api = apis[i];
    const raw = api.url + encodeURIComponent(kw);
    const via = `/api/proxy?url=${encodeURIComponent(raw)}`;

    for (const ep of [raw, via]) {
      try {
        const r = await fetch(ep, { signal: AbortSignal.timeout(8000) });
        if (!r.ok) continue;
        const j = await r.json().catch(() => null);
        if (j?.list) return { data: j, idx: i, name: api.name };
      } catch {}
    }
  }
  return null;
}

async function fetchById(vod_id) {
  for (const api of enabledApis()) {
    // 构造 ids= 请求，移除末尾的 wd=
    const base = api.url.replace(/[?&]?wd=$/, '');
    const sep  = base.includes('?') ? '&' : '?';
    const raw  = `${base}${sep}ac=detail&ids=${vod_id}`;
    const via  = `/api/proxy?url=${encodeURIComponent(raw)}`;

    for (const ep of [raw, via]) {
      try {
        const r = await fetch(ep, { signal: AbortSignal.timeout(8000) });
        if (!r.ok) continue;
        const j = await r.json().catch(() => null);
        if (j?.list?.length) return j.list[0];
      } catch {}
    }
  }
  return null;
}

/* ══════════════════════════════════════════════════════
   首页
══════════════════════════════════════════════════════ */
const CATS = [
  { label:'🎬 热播电影', kw:'电影' },
  { label:'📺 热播剧集', kw:'电视剧' },
  { label:'✨ 热播动漫', kw:'动漫' },
  { label:'🎤 综艺节目', kw:'综艺' },
];

function buildHome() {
  const wrap = $('homeWrap'); wrap.innerHTML = '';
  CATS.forEach(cat => {
    const sec = document.createElement('div');
    sec.className = 'sec';
    sec.innerHTML = `
      <div class="sec-hd">
        <h3>${cat.label}</h3>
        <a class="sec-more" onclick="loadCat('${cat.kw}')">更多 →</a>
      </div>`;
    const row = document.createElement('div');
    row.className = 'row-scroll';
    makeSkels(8).forEach(s => row.appendChild(s));
    sec.appendChild(row);
    wrap.appendChild(sec);

    fetchByKw(cat.kw).then(res => {
      row.innerHTML = '';
      const items = res?.data?.list || [];
      if (items.length) items.slice(0, 14).forEach(it => row.appendChild(makeCard(it, true)));
      else row.innerHTML = '<div class="row-empty">暂无数据，请在设置中配置 API</div>';
    });
  });
}

/* ── Hero 轮播 ────────────────────────────────────── */
async function loadHero() {
  const res = await fetchByKw('热播');
  G.hero.items = (res?.data?.list || []).slice(0, 6);
  if (!G.hero.items.length) return;
  renderHero(0); buildDots(); startHeroTimer();
}
function renderHero(i) {
  G.hero.cur = i;
  const it = G.hero.items[i];
  $('heroTag').textContent   = it.type_name || '推荐';
  $('heroTitle').textContent = it.vod_name || '';
  $('heroDesc').textContent  = (it.vod_blurb || it.vod_content || '').replace(/<[^>]+>/g, '').slice(0, 120);
  if (it.vod_pic) $('heroBg').style.cssText = `background-image:url(${CSS.escape?CSS.escape(it.vod_pic):it.vod_pic});background-size:cover;background-position:center`;
  $$('.dot').forEach((d, j) => d.classList.toggle('on', j === i));
}
function buildDots() {
  const c = $('heroDots'); c.innerHTML = '';
  G.hero.items.forEach((_, i) => {
    const d = document.createElement('span'); d.className = 'dot' + (i === 0 ? ' on' : '');
    d.onclick = () => { clearInterval(G.hero.timer); renderHero(i); startHeroTimer(); };
    c.appendChild(d);
  });
}
function startHeroTimer() {
  clearInterval(G.hero.timer);
  G.hero.timer = setInterval(() => renderHero((G.hero.cur + 1) % G.hero.items.length), 5000);
}
function playHero()   { if (G.hero.items.length) openPlayer(G.hero.items[G.hero.cur]); }
function detailHero() { if (G.hero.items.length) openPlayer(G.hero.items[G.hero.cur]); }

/* ══════════════════════════════════════════════════════
   列表 / 搜索
══════════════════════════════════════════════════════ */
function doSearch() {
  const kw = $('searchInput').value.trim();
  if (!kw) { toast('请输入搜索关键词'); return; }
  showList(kw, false);
}
$('searchInput').addEventListener('keydown', e => { if (e.key === 'Enter') doSearch(); });

async function loadCat(kw) { showList(kw, true); }

async function showList(kw, isCat) {
  openPage('listPage');
  G.list = { all:[], filtered:[], page:1, kw };
  $('listTitle').textContent = isCat ? kw : `"${kw}" 的结果`;
  $('listFilters').innerHTML = isCat ? '' : `
    <button class="flt active" onclick="filterList('all',this)">全部</button>
    <button class="flt" onclick="filterList('电影',this)">电影</button>
    <button class="flt" onclick="filterList('电视剧',this)">剧集</button>
    <button class="flt" onclick="filterList('动漫',this)">动漫</button>`;

  const grid = $('listGrid'); grid.innerHTML = '';
  makeSkels(16, 'card').forEach(s => grid.appendChild(s));

  const res = await fetchByKw(kw);
  G.list.all = res?.data?.list || [];
  G.list.filtered = [...G.list.all];
  renderList();
  if (!G.list.all.length) {
    grid.innerHTML = '<div class="empty-box"><div>🔍</div><p>未找到相关内容</p><small style="color:var(--c-text3)">可在设置 → API管理 中添加更多数据源</small></div>';
  }
}

function filterList(type, btn) {
  $$('.flt').forEach(b => b.classList.remove('active')); btn.classList.add('active');
  G.list.filtered = type === 'all' ? [...G.list.all] : G.list.all.filter(it => it.type_name?.includes(type));
  G.list.page = 1; renderList();
}
function renderList() {
  const grid = $('listGrid'); grid.innerHTML = '';
  const sl = G.list.filtered.slice(0, G.list.page * 24);
  sl.forEach(it => grid.appendChild(makeCard(it, false)));
  $('listMore').style.display = sl.length < G.list.filtered.length ? 'block' : 'none';
}
function loadMoreList() { G.list.page++; renderList(); }

/* ══════════════════════════════════════════════════════
   播放器
══════════════════════════════════════════════════════ */
async function openPlayer(item) {
  if (!item) return;
  G.play = { item, ep:0, src:0 };
  openPage('playerPage');
  const name = item.vod_name || '';
  $('pTopTitle').textContent = name;
  $('pTitle').textContent    = name;
  $('pDesc').textContent     = (item.vod_blurb || item.vod_content || '').replace(/<[^>]+>/g, '');
  $('pMeta').innerHTML       = buildMeta(item);
  $('resSelect').value       = G.cfg.res;
  buildSrcSel();
  spin(true); $('vidErr').style.display = 'none';

  let detail = item;
  if (!item.vod_play_url && item.vod_id) {
    detail = (await fetchById(item.vod_id)) || item;
    G.play.item = detail;
  }
  buildEps(detail);
  loadRel(detail.type_name || '');
  addHist(detail);
  playEp(0);
}

function buildMeta(it) {
  return [['年份', it.vod_year], ['地区', it.vod_area], ['类型', it.type_name], ['评分', it.vod_score ? '★'+it.vod_score : null]]
    .filter(([,v]) => v).map(([k,v]) => `<span><b>${k}：</b>${esc(v)}</span>`).join('');
}

function buildSrcSel() {
  const sel = $('srcSelect'); sel.innerHTML = '';
  enabledApis().forEach((a, i) => {
    const o = document.createElement('option'); o.value = i; o.textContent = a.name; sel.appendChild(o);
  });
  sel.value = G.play.src;
}

function parseEps(item) {
  if (!item?.vod_play_url) return [];
  return item.vod_play_url.split('#').filter(Boolean).map((seg, i) => {
    const p = seg.split('$');
    return { name: p[0] || `第${i+1}集`, url: p.slice(1).join('$') || p[0] };
  });
}

function buildEps(item) {
  const eps = parseEps(item);
  $('epCount').textContent = eps.length + '集';
  const g = $('epGrid'); g.innerHTML = '';
  eps.forEach((ep, i) => {
    const b = document.createElement('button'); b.className = 'ep-btn';
    b.textContent = ep.name || `第${i+1}集`;
    b.onclick = () => playEp(i);
    g.appendChild(b);
  });
}

function playEp(idx) {
  G.play.ep = idx;
  const eps = parseEps(G.play.item);
  if (!eps[idx]) { toast('暂无播放地址'); spin(false); return; }
  $$('.ep-btn').forEach((b, i) => b.classList.toggle('active', i === idx));
  doPlay(applyRes(eps[idx].url, $('resSelect').value));
  saveProg(G.play.item?.vod_id, idx);
}

function applyRes(url, res) {
  if (!url) return url;
  // 替换路径中的分辨率字段
  url = url.replace(/[_\/](1080|720|480|360)(p?)([._\/])/gi, `_${res}$2$3`);
  // 对 m3u8 添加 resolution 参数（部分CDN支持）
  if (url.includes('.m3u8') && !/resolution|quality/i.test(url)) {
    url += (url.includes('?') ? '&' : '?') + 'resolution=' + res;
  }
  return url;
}

function doPlay(url) {
  const vid = $('vid');
  spin(true); $('vidErr').style.display = 'none';
  // 销毁旧 HLS 实例
  if (window._hls) { window._hls.destroy(); window._hls = null; }

  if (!url) { spin(false); showErr(); return; }

  if (url.includes('.m3u8')) {
    if (window.Hls?.isSupported()) {
      const hls = new Hls({ enableWorker:true, lowLatencyMode:false });
      window._hls = hls;
      hls.loadSource(url);
      hls.attachMedia(vid);
      hls.on(Hls.Events.MANIFEST_PARSED, () => {
        spin(false);
        if (G.cfg.autoPlay) vid.play().catch(() => {});
        restoreProg(G.play.item?.vod_id, G.play.ep, vid);
      });
      hls.on(Hls.Events.ERROR, (_, d) => {
        if (d.fatal) { spin(false); showErr(); }
      });
    } else if (vid.canPlayType('application/vnd.apple.mpegurl')) {
      vid.src = url;
      vid.onloadeddata = () => { spin(false); if (G.cfg.autoPlay) vid.play().catch(() => {}); };
      vid.onerror = () => { spin(false); showErr(); };
    } else {
      spin(false); toast('浏览器不支持HLS，推荐使用 Chrome / Safari');
    }
  } else {
    vid.src = url;
    vid.onloadeddata = () => { spin(false); if (G.cfg.autoPlay) vid.play().catch(() => {}); };
    vid.onerror   = () => { spin(false); showErr(); };
  }
}

function showErr() {
  $('vidErr').style.display = 'flex';
  if (G.cfg.autoSrc) setTimeout(tryNextSrc, 1000);
}
function tryNextSrc() {
  $('vidErr').style.display = 'none';
  const apis = enabledApis();
  if (G.play.src < apis.length - 1) {
    G.play.src++;
    $('srcSelect').value = G.play.src;
    toast(`自动切换至 ${apis[G.play.src]?.name}`);
    openPlayer(G.play.item);
  } else {
    toast('所有线路均无法播放');
  }
}
function changeRes(r) {
  const t = $('vid').currentTime;
  G.cfg.res = r; saveCfg();
  playEp(G.play.ep);
  $('vid').addEventListener('canplay', () => { $('vid').currentTime = t; }, { once:true });
  toast(`已切换 ${r}P`);
}
function changeSrc(idx) {
  G.play.src = parseInt(idx);
  toast(`切换至 ${enabledApis()[idx]?.name}`);
  openPlayer(G.play.item);
}
function spin(on) { $('spinWrap').style.display = on ? 'flex' : 'none'; }

async function loadRel(type) {
  const list = $('relList'); list.innerHTML = '<div class="rel-loading">加载中…</div>';
  const res = await fetchByKw(type || '热播');
  list.innerHTML = '';
  (res?.data?.list || []).filter(it => it.vod_id !== G.play.item?.vod_id).slice(0, 8).forEach(it => {
    const d = document.createElement('div'); d.className = 'rel-item'; d.onclick = () => openPlayer(it);
    d.innerHTML = `
      <div class="rel-img">${it.vod_pic ? `<img src="${esc(it.vod_pic)}" loading="lazy">` : ''}</div>
      <div class="rel-info">
        <div class="rel-name">${esc(it.vod_name || '')}</div>
        <div class="rel-sub">${esc(it.type_name || '')}${it.vod_year ? ' · '+it.vod_year : ''}</div>
      </div>`;
    list.appendChild(d);
  });
}

/* ══════════════════════════════════════════════════════
   历史 & 进度
══════════════════════════════════════════════════════ */
function addHist(it) {
  G.hist = [
    { vod_id:it.vod_id, vod_name:it.vod_name, vod_pic:it.vod_pic, type_name:it.type_name, ep:0, progress:0, ts:Date.now() },
    ...G.hist.filter(h => h.vod_id !== it.vod_id),
  ].slice(0, 100);
  saveHist();
}
function saveProg(id, ep) {
  if (!G.cfg.progress || !id) return;
  const p = JSON.parse(localStorage.getItem('baihu_prog') || '{}');
  p[id] = { ep, t:0, ts:Date.now() };
  $('vid').addEventListener('timeupdate', function onTU() {
    if ($('vid').currentTime > 5) {
      p[id].t = $('vid').currentTime;
      localStorage.setItem('baihu_prog', JSON.stringify(p));
    }
  });
  localStorage.setItem('baihu_prog', JSON.stringify(p));
}
function restoreProg(id, ep, vid) {
  if (!G.cfg.progress || !id) return;
  const p = JSON.parse(localStorage.getItem('baihu_prog') || '{}');
  if (p[id]?.ep === ep && p[id].t > 10) {
    vid.addEventListener('canplay', () => { vid.currentTime = p[id].t; }, { once:true });
  }
}
function showHist() {
  const list = $('histList'); list.innerHTML = '';
  if (!G.hist.length) {
    list.innerHTML = '<div class="empty-box" style="padding:40px 0"><div>📭</div><p>暂无记录</p></div>';
  } else {
    G.hist.forEach(it => {
      const d = document.createElement('div'); d.className = 'hist-item';
      d.onclick = () => { closeHist(); openPlayer(it); };
      d.innerHTML = `
        <div class="hist-img">${it.vod_pic ? `<img src="${esc(it.vod_pic)}" loading="lazy">` : ''}</div>
        <div class="hist-info">
          <div class="hist-name">${esc(it.vod_name || '')}</div>
          <div class="hist-sub">${it.type_name || '—'} · ${fmtTs(it.ts)}</div>
        </div>
        <button class="hist-del" onclick="event.stopPropagation();delHist('${it.vod_id}')">✕</button>`;
      list.appendChild(d);
    });
  }
  $('histOverlay').style.display = 'block'; $('histModal').style.display = 'flex';
}
function delHist(id) { G.hist = G.hist.filter(h => h.vod_id !== id); saveHist(); showHist(); }
function clearHist() { if (!confirm('确认清空全部历史？')) return; G.hist=[]; saveHist(); showHist(); }
function closeHist() { $('histOverlay').style.display = 'none'; $('histModal').style.display = 'none'; }
function fmtTs(ts) {
  const d = new Date(ts), n = new Date();
  return d.toDateString() === n.toDateString()
    ? '今天 ' + d.toTimeString().slice(0,5)
    : d.toLocaleDateString('zh-CN', { month:'short', day:'numeric' });
}

/* ══════════════════════════════════════════════════════
   设置面板
══════════════════════════════════════════════════════ */
function openSettings() {
  loadSettingsUI();
  $('settOverlay').style.display = 'block';
  $('settDrawer').classList.add('open');
}
function closeSettings() {
  $('settOverlay').style.display = 'none';
  $('settDrawer').classList.remove('open');
}
function switchTab(id, btn) {
  $$('.tab-panel').forEach(p => p.classList.remove('active'));
  $$('.tab').forEach(b => b.classList.remove('active'));
  $(id).classList.add('active');
  btn.classList.add('active');
}
function loadSettingsUI() {
  $('cfgRes').value       = G.cfg.res;
  $('cfgAutoPlay').checked = G.cfg.autoPlay;
  $('cfgProgress').checked = G.cfg.progress;
  $('cfgAutoSrc').checked  = G.cfg.autoSrc;
  renderApiList();
  updateSyncStatus();
}
function savePlayCfg() {
  G.cfg.res      = $('cfgRes').value;
  G.cfg.autoPlay = $('cfgAutoPlay').checked;
  G.cfg.progress = $('cfgProgress').checked;
  G.cfg.autoSrc  = $('cfgAutoSrc').checked;
  saveCfg(); toast('✅ 已保存');
}
function setTheme(t, el) {
  $$('.tp').forEach(e => e.classList.remove('on')); el.classList.add('on');
  G.cfg.theme = t; saveCfg(); applyTheme(t);
}
function applyTheme(t) { document.documentElement.dataset.theme = t === 'dark' ? '' : t; }

/* ══════════════════════════════════════════════════════
   API 管理
══════════════════════════════════════════════════════ */
function renderApiList() {
  const el = $('apiList'); el.innerHTML = '';
  if (!G.apis.length) {
    el.innerHTML = '<div class="empty-box" style="padding:24px 0"><div>📡</div><p>暂无 API，点击"抓取"或手动添加</p></div>';
    return;
  }
  G.apis.forEach((api, idx) => {
    const d = document.createElement('div'); d.className = 'api-item'; d.dataset.id = api.id;
    d.draggable = true;
    const stMap  = { ok:'st-ok', fail:'st-fail', unknown:'st-unk' };
    const stLbl  = { ok:`✓ ${api.latency}ms`, fail:'✗ 不可用', unknown:'— 未测' };
    const st     = api.status || 'unknown';
    d.innerHTML = `
      <span class="api-drag" title="拖动排序">⋮⋮</span>
      <label class="toggle sm"><input type="checkbox" ${api.enabled!==false?'checked':''} onchange="toggleApi('${api.id}',this.checked)"><span class="track"></span></label>
      <div class="api-main">
        <div class="api-name-row">
          <span class="api-name">${esc(api.name)}</span>
          ${api.custom ? '<span class="badge-custom">自定义</span>' : ''}
          ${idx === 0  ? '<span class="badge-main">主源</span>' : ''}
        </div>
        <div class="api-url">${esc(api.url)}</div>
        ${api.note ? `<div class="api-note">${esc(api.note)}</div>` : ''}
      </div>
      <div class="api-stat"><span class="st ${stMap[st]}">${stLbl[st]}</span></div>
      <div class="api-ops">
        <button class="btn-icon" onclick="testOne('${api.id}')" title="测速">⚡</button>
        <button class="btn-icon" onclick="editApi('${api.id}')" title="编辑">✏️</button>
        <button class="btn-icon btn-del" onclick="delApi('${api.id}')" title="删除">🗑</button>
      </div>`;
    el.appendChild(d);
  });
  initDrag();
}

function toggleApi(id, enabled) {
  const a = G.apis.find(a => a.id === id);
  if (a) { a.enabled = enabled; saveApiList(G.apis); }
}

async function testOne(id) {
  const api = G.apis.find(a => a.id === id);
  if (!api) return;
  toast(`测试 ${api.name}…`);
  const r = await testApiItem(api);
  api.status = r.ok ? 'ok' : 'fail';
  api.latency = r.latency;
  saveApiList(G.apis); renderApiList();
  toast(r.ok ? `✅ ${api.name} 可用 ${r.latency}ms` : `❌ ${api.name} 不可用`);
}

async function testAllApis() {
  const btn = $('testAllBtn'); btn.disabled = true; btn.textContent = '测速中…';
  showProg(0, G.apis.length, '准备…');
  await batchTestApis(G.apis, (done, total, name, r) => {
    showProg(done, total, `${name} ${r?.ok ? '✓' : '✗'}`);
    const api = G.apis.find(a => a.name === name);
    if (api) { api.status = r?.ok ? 'ok' : 'fail'; api.latency = r?.latency ?? null; }
    saveApiList(G.apis); renderApiList();
  });
  // 可用的排前面，按延迟升序
  G.apis.sort((a, b) => {
    if (a.status==='ok' && b.status!=='ok') return -1;
    if (b.status==='ok' && a.status!=='ok') return 1;
    return (a.latency||9999) - (b.latency||9999);
  });
  saveApiList(G.apis); renderApiList();
  hideProg();
  const ok = G.apis.filter(a => a.status==='ok').length;
  toast(`✅ 测速完成：${ok}/${G.apis.length} 可用，已排序`);
  btn.disabled = false; btn.textContent = '⚡ 全部测速';
}

async function scanApis() {
  const btn = $('scanBtn'); btn.disabled = true; btn.textContent = '抓取中…';
  let added = 0;
  BUILTIN_APIS.forEach(b => {
    if (!G.apis.some(a => a.url === b.url)) {
      G.apis.push({ ...b, id: uid(), status:'unknown', latency:null, enabled:true, custom:false });
      added++;
    }
  });
  saveApiList(G.apis); renderApiList();
  toast(`已载入 ${added} 条新 API，开始验活…`);

  const unknowns = G.apis.filter(a => a.status === 'unknown');
  showProg(0, unknowns.length, '验证中…');
  await batchTestApis(unknowns, (done, total, name, r) => {
    showProg(done, total, name + '…');
    const api = G.apis.find(a => a.name === name);
    if (api) { api.status = r?.ok ? 'ok' : 'fail'; api.latency = r?.latency ?? null; }
    saveApiList(G.apis); renderApiList();
  });
  G.apis.sort((a, b) => {
    if (a.status==='ok' && b.status!=='ok') return -1;
    if (b.status==='ok' && a.status!=='ok') return 1;
    return (a.latency||9999) - (b.latency||9999);
  });
  saveApiList(G.apis); renderApiList(); hideProg();
  const ok = G.apis.filter(a => a.status==='ok').length;
  toast(`🎉 扫描完成！${ok} 个可用 API 已排在前面`);
  btn.disabled = false; btn.textContent = '🔍 抓取可用API';
}

function showProg(cur, total, txt) {
  $('scanProgress').style.display = 'block';
  $('progressFill').style.width   = total ? (cur/total*100)+'%' : '0';
  $('progressTxt').textContent    = `${cur}/${total} ${txt}`;
}
function hideProg() { setTimeout(() => { $('scanProgress').style.display='none'; }, 1500); }

function delApi(id) {
  if (!confirm('确认删除？')) return;
  G.apis = G.apis.filter(a => a.id !== id);
  saveApiList(G.apis); renderApiList(); toast('已删除');
}

/* ── 添加/编辑弹窗 ─────────────────────────────────── */
function openAddApi() {
  G.editId = null; $('apiModalTitle').textContent = '添加 API';
  $('apiName').value = $('apiUrl').value = $('apiNote').value = '';
  $('apiTestResult').style.display = 'none';
  $('apiOverlay').style.display = 'block'; $('apiModal').style.display = 'flex';
}
function editApi(id) {
  const api = G.apis.find(a => a.id === id); if (!api) return;
  G.editId = id; $('apiModalTitle').textContent = '编辑 API';
  $('apiName').value = api.name; $('apiUrl').value = api.url; $('apiNote').value = api.note || '';
  $('apiTestResult').style.display = 'none';
  $('apiOverlay').style.display = 'block'; $('apiModal').style.display = 'flex';
}
function closeAddApi() { $('apiOverlay').style.display = 'none'; $('apiModal').style.display = 'none'; }
async function testSingleApi() {
  const url = $('apiUrl').value.trim(); if (!url) { toast('请先填写 API 地址'); return; }
  const el = $('apiTestResult'); el.style.display='block'; el.className='api-test-result testing'; el.textContent='测试中…';
  const r = await testApiItem({ url }, '电影', 9000);
  if (r.ok) { el.className='api-test-result ok'; el.textContent=`✅ 可用！延迟 ${r.latency}ms，返回 ${r.count} 条`; }
  else       { el.className='api-test-result fail'; el.textContent=`❌ 不可用：${r.error||'无响应'}`; }
}
function confirmApi() {
  const name = $('apiName').value.trim();
  const url  = $('apiUrl').value.trim();
  const note = $('apiNote').value.trim();
  if (!name) { toast('请填写名称'); return; }
  if (!url || !url.startsWith('http')) { toast('请填写正确的 API 地址'); return; }
  if (G.editId) {
    const api = G.apis.find(a => a.id === G.editId);
    if (api) { api.name=name; api.url=url; api.note=note; api.status='unknown'; api.latency=null; }
  } else {
    G.apis.push({ id:uid(), name, url, note, status:'unknown', latency:null, enabled:true, custom:true });
  }
  saveApiList(G.apis); renderApiList(); closeAddApi();
  toast(G.editId ? '✅ 已更新' : '✅ 已添加，建议点击测速验证');
}

/* ── 拖拽排序 ─────────────────────────────────────── */
function initDrag() {
  const con = $('apiList');
  let dragging = null;
  $$('#apiList .api-item').forEach(el => {
    el.addEventListener('dragstart', () => { dragging=el; el.classList.add('dragging'); });
    el.addEventListener('dragend',   () => { el.classList.remove('dragging'); dragging=null; persistOrder(); });
    el.addEventListener('dragover',  e => {
      e.preventDefault();
      const after = [...$$('#apiList .api-item:not(.dragging)')].find(n => {
        return e.clientY < n.getBoundingClientRect().top + n.getBoundingClientRect().height / 2;
      });
      after ? con.insertBefore(dragging, after) : con.appendChild(dragging);
    });
  });
}
function persistOrder() {
  const ids = [...$$('#apiList .api-item')].map(el => el.dataset.id);
  G.apis = ids.map(id => G.apis.find(a => a.id===id)).filter(Boolean);
  saveApiList(G.apis);
}

/* ══════════════════════════════════════════════════════
   D1 云同步
══════════════════════════════════════════════════════ */
function setSyncSt(msg, cls) {
  const el = $('syncStatus');
  if (!el) return;
  el.textContent = msg;
  el.className   = 'sync-status ' + (cls||'');
  el.style.display = 'block';
}
function updateSyncStatus() { setSyncSt('就绪，点击按钮同步数据', 'sync-ing'); }

async function d1Req(method, path, body) {
  const r = await fetch('/api/d1/' + path, {
    method,
    headers: { 'Content-Type':'application/json', 'X-Token': G.token },
    body: body ? JSON.stringify(body) : undefined,
  });
  return r.json().catch(() => ({ error:'解析失败' }));
}

async function d1Push(type) {
  setSyncSt('上传中…', 'sync-ing');
  try {
    let j;
    if (type === 'apis') j = await d1Req('POST', 'apis', { apis: G.apis });
    else                  j = await d1Req('POST', 'history', { history: G.hist });
    j.ok ? setSyncSt(`✅ ${type==='apis'?'API列表':'历史记录'}已上传`, 'sync-ok')
          : setSyncSt('❌ 上传失败：' + (j.error||'未知'), 'sync-err');
  } catch(e) { setSyncSt('❌ 网络错误：' + e.message, 'sync-err'); }
}

async function d1Pull(type) {
  setSyncSt('拉取中…', 'sync-ing');
  try {
    const j = await d1Req('GET', type === 'apis' ? 'apis' : 'history');
    if (!j.ok) { setSyncSt('❌ 拉取失败：' + (j.error||'未知'), 'sync-err'); return; }
    if (type === 'apis' && j.data?.length) {
      G.apis = j.data; saveApiList(G.apis); renderApiList();
      setSyncSt(`✅ 已拉取 ${j.data.length} 条 API`, 'sync-ok');
    } else if (type === 'history' && j.data?.length) {
      G.hist = j.data; saveHist();
      setSyncSt(`✅ 已拉取 ${j.data.length} 条历史`, 'sync-ok');
    } else {
      setSyncSt('云端暂无数据', 'sync-ing');
    }
  } catch(e) { setSyncSt('❌ 网络错误：' + e.message, 'sync-err'); }
}

async function d1PushAll() { await d1Push('apis'); await d1Push('history'); }
async function d1PullAll() { await d1Pull('apis'); await d1Pull('history'); }

/* ══════════════════════════════════════════════════════
   卡片 & 骨架
══════════════════════════════════════════════════════ */
function makeCard(it, sm) {
  const d = document.createElement('div');
  d.className = 'card' + (sm ? ' card-sm' : '');
  d.onclick = () => openPlayer(it);
  d.innerHTML = `
    <div class="card-img">
      ${it.vod_pic ? `<img src="${esc(it.vod_pic)}" loading="lazy" alt="" onerror="this.style.display='none'">` : `<div class="no-pic">暂无封面</div>`}
      ${it.vod_remarks ? `<span class="badge-rmk">${esc(it.vod_remarks)}</span>` : ''}
      ${it.vod_score ? `<span class="badge-score">★${parseFloat(it.vod_score).toFixed(1)}</span>` : ''}
      <div class="card-hover"><span>▶</span></div>
    </div>
    <div class="card-foot">
      <div class="card-name">${esc(it.vod_name || '')}</div>
      <div class="card-sub">${esc(it.type_name || '')}${it.vod_year ? ' · '+it.vod_year : ''}</div>
    </div>`;
  return d;
}
function makeSkels(n) {
  return Array.from({ length:n }, () => {
    const d = document.createElement('div'); d.className = 'skel-card';
    d.innerHTML = '<div class="skel skel-img"></div><div class="skel skel-ln"></div><div class="skel skel-ln s"></div>';
    return d;
  });
}

/* ══════════════════════════════════════════════════════
   页面路由
══════════════════════════════════════════════════════ */
const PAGES = ['homePage','listPage','playerPage'];

function openPage(id) {
  PAGES.forEach(p => { $(p).style.display = p===id ? '' : 'none'; });
  if (id !== 'playerPage') { document.body.style.overflow = ''; }
  else                     { document.body.style.overflow = 'hidden'; }
  window.scrollTo(0, 0);
  if (id !== 'homePage') clearInterval(G.hero.timer);
}

function closePage(id) {
  if (id === 'playerPage') {
    const v = $('vid'); v.pause(); v.src = '';
    if (window._hls) { window._hls.destroy(); window._hls = null; }
  }
  openPage('homePage');
  if (id === 'homePage') { loadHero(); }
}
function goHome() { closePage(null); openPage('homePage'); loadHero(); }

/* ══════════════════════════════════════════════════════
   键盘快捷键
══════════════════════════════════════════════════════ */
document.addEventListener('keydown', e => {
  // 弹窗/抽屉
  if ($('settDrawer').classList.contains('open')) { if(e.key==='Escape') closeSettings(); return; }
  if ($('apiModal').style.display  !=='none') { if(e.key==='Escape') closeAddApi(); return; }
  if ($('histModal').style.display !=='none') { if(e.key==='Escape') closeHist();   return; }

  // 播放器快捷键
  if ($('playerPage').style.display !== 'none') {
    const v = $('vid');
    if (e.key==='Escape')      { e.preventDefault(); closePage('playerPage'); }
    if (e.key===' ')           { e.preventDefault(); v.paused ? v.play() : v.pause(); }
    if (e.key==='ArrowRight')  { e.preventDefault(); v.currentTime += 10; }
    if (e.key==='ArrowLeft')   { e.preventDefault(); v.currentTime -= 10; }
    if (e.key==='ArrowUp')     { e.preventDefault(); v.volume = Math.min(1, v.volume+0.1); }
    if (e.key==='ArrowDown')   { e.preventDefault(); v.volume = Math.max(0, v.volume-0.1); }
    if (e.key==='f'||e.key==='F') v.requestFullscreen?.();
  }
  if ($('listPage').style.display !== 'none' && e.key==='Escape') closePage('listPage');
});

/* ══════════════════════════════════════════════════════
   HLS.js 懒加载
══════════════════════════════════════════════════════ */
function loadHlsJs() {
  if (window.Hls) return;
  const s = document.createElement('script');
  s.src = 'https://cdnjs.cloudflare.com/ajax/libs/hls.js/1.4.12/hls.min.js';
  s.onerror = () => { console.warn('HLS.js 加载失败，m3u8 在 iOS Safari 上仍可播放'); };
  document.head.appendChild(s);
}
